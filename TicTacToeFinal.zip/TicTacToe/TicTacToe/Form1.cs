﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class ticTacToefrm : Form
    {

        Label[,] grid = new Label[3, 3];
        char[,] game = new char[3, 3];

        int numClicks;
        bool isXTurn;
        bool isDone;
        char winner = 'N';

        public ticTacToefrm()
        {
            InitializeComponent();
        }

        private void ticTacToefrm_Load(object sender, EventArgs e)
        {

            resetGame();
            grid = new Label[3, 3]{
                {label1, label2, label3},
                {label4, label5, label6},
                {label7, label8, label9}
            };


        }




        public void resetGame()
        {


            Label[,] grid ={
                {label1, label2, label3},
                {label4, label5, label6},
                {label7, label8, label9}
            };




            char[,] game = {
                {' ', ' ', ' '},
                {' ', ' ', ' '},
                {' ', ' ', ' '}
            };

            numClicks = 0;
            isXTurn = true;
            lblStatus.Text = "Welcome to Tic-Tac-Toe";
            winner = 'N';

            //replace with for loop



            int row, col;
            for (row = 0; row <= 2; row++)
            {


                for (col = 0; col <= 2; col++)
                {
                    grid[row, col].Text = string.Empty;
                    game[row, col] = ' ';

                }


            }








        }


        public void gameOver()

        {


            if ((game[0, 2] == 'O') && (game[1, 1] == 'O') && (game[2, 0] == 'O')
            || (game[0, 0] == 'O') && (game[0, 1] == 'O') && (game[0, 2] == 'O')
            || (game[0, 0] == 'O') && (game[1, 1] == 'O') && (game[2, 2] == 'O')
            || (game[1, 0] == 'O') && (game[1, 1] == 'O') && (game[1, 2] == 'O')
            || (game[2, 0] == 'O') && (game[2, 1] == 'O') && (game[2, 2] == 'O')
            || (game[0, 0] == 'O') && (game[1, 0] == 'O') && (game[2, 0] == 'O')
            || (game[0, 1] == 'O') && (game[1, 1] == 'O') && (game[1, 2] == 'O')
            || (game[0, 2] == 'O') && (game[1, 2] == 'O') && (game[2, 2] == 'O'))
            {
                isDone = true; winner = 'O';
                lblStatus.Text = "O wins!";

            }

            if ((game[0, 0] == 'X') && (game[1, 1] == 'X') && (game[2, 2] == 'X')
            || (game[0, 2] == 'X') && (game[1, 1] == 'X') && (game[2, 0] == 'X')
            || (game[0, 0] == 'X') && (game[0, 1] == 'X') && (game[0, 2] == 'X')
            || (game[1, 0] == 'X') && (game[1, 1] == 'X') && (game[1, 2] == 'X')
            || (game[2, 0] == 'X') && (game[2, 1] == 'X') && (game[2, 2] == 'X')
            || (game[0, 0] == 'X') && (game[1, 0] == 'X') && (game[2, 0] == 'X')
            || (game[0, 1] == 'X') && (game[1, 1] == 'X') && (game[1, 2] == 'X')
            || (game[0, 2] == 'X') && (game[1, 2] == 'X') && (game[2, 2] == 'X'))
            {



                isDone = true;
                winner = 'X';
                lblStatus.Text = "X wins!";




            }

            



            else if (numClicks == 9)
            {
                isDone = true;
                winner = 'T';
                lblStatus.Text = "It's a tie!";



            }



        }






        private void label1_Click(object sender, EventArgs e)
        {
            Label label = (Label)sender; // cast sender to a Label



            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (label == grid[row, col])
                    {
                        if (label.Text != string.Empty)
                        {
                            lblStatus.Text = "Invalid Move";
                            return;
                        }
                        else if (label.Text == string.Empty && isXTurn == true)
                        {

                            label.Text = "X";
                            label.ForeColor = Color.Red;
                            game[row, col] = 'X';
                            lblStatus.Text = "O's Turn";
                        }
                        else
                        {



                            label.Text = "O";
                            label.ForeColor = Color.Blue;
                            game[row, col] = 'O';
                            lblStatus.Text = "X's Turn";
                        }
                        isXTurn = !isXTurn;
                        numClicks++;
                        gameOver();


                    }
                }
            }
        }



        private void lblStatus_Click(object sender, EventArgs e)
        {

        }

        private void restartBtn_Click(object sender, EventArgs e)
        {


            int row, col;
            for (row = 0; row <= 2; row++)
            {


                for (col = 0; col <= 2; col++)
                {
                    grid[row, col].Text = string.Empty;
                    game[row, col] = ' ';

                }



                resetGame();
                isDone = false;
                lblStatus.Text = "Welcome to Tic-Tac-Toe.";
                isXTurn = true;


            }
        }

    }
}



